import React from 'react';
import logo from './logo.svg';
import Header from './components/header/header';
import Divider from './components/divider/divider';
import Feed from './components/feed/feed';
import BotMenu from './components/botmenu/botmenu';
import './App.css';


function App() {
  return (
    <div className="app">
      <Header />
      <Divider />
      <Feed />
      <BotMenu />
    </div>
  );
}

export default App;
