import React, { useEffect, useState } from 'react';
import ContentBlock from '../contentblock/contentblock';

const Feed = () => {
  const [contentBlocks, setContentBlocks] = useState([]);

  useEffect(() => {
    fetch('./api/content')
      .then(response => response.json())
      .then(data => setContentBlocks(data))
      .catch(error => console.error('Error:', error));
  }, []);

  return (
    <div className="feed">
      {contentBlocks.map((block, index) => (
        <ContentBlock key={index} text={block.context} />
      ))}
    </div>
  );
};

export default Feed;
