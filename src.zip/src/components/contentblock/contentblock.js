import React from 'react';


function ContentBlock({ text }) {
    return (
      <div className="content-block">
        {text}
      </div>
    );
  }
  
  
  export default ContentBlock;
