import React from 'react';
import './header.css';

const Header = () => {
  return (
    <div className="header">
      <div className="profile-section">
        <img src="images\Deric Passport Photo.png" alt="Profile" className="profile-pic"/>
        <div className="profile-name">Profile Name</div>
      </div>
      <div className="followers-section">
        <span className="followers-label">Community: </span>
        <span className="followers-count">0</span>
      </div>
    </div>
  );
}

export default Header;
