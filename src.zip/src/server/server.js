const express = require('express');
const cors = require('cors');
const { Client } = require('pg');
const app = express();
const port = 60000;

app.use(cors({ origin: 'http://192.168.1.84:3000' }));
 // Use cors middleware

const client = new Client({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'wolf1',
  database: 'postgres'
});

client.connect()
  .then(() => console.log('Connected to PostgreSQL database'))
  .catch(err => console.error('Connection error', err.stack));

app.get('/api/content', (req, res) => {
  client.query('SELECT * FROM content_blocks', (error, results) => {
    if (error) {
      throw error;
    }
    console.log(results.rows);  // Add this line
    res.status(200).json(results.rows);
  });
});

app.listen(port, '0.0.0.0', () => {
  console.log(`Server running on port ${port}`);
});

  